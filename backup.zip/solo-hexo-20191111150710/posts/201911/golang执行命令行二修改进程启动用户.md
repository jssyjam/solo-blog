title: golang 执行命令行(二)--修改进程启动用户
date: '2019-11-05 20:10:41'
updated: '2019-11-05 20:11:15'
tags: [golang, 杂货铺]
permalink: /articles/2019/11/05/1572955840987.html
---
继续[上文](http://www.jssyjam.com/articles/2019/08/02/1564732049754.html)所述,有时候我们需要设置进程的启动用户,操作与设置进程组的方式类似,不多说直接上代码:

```go
// 修改进程的执行用户
func withUserAttr(cmd *exec.Cmd, name string) error {
	// 检测用户是否存在
	user, err := user.Lookup(name)
	if err != nil {
		return errors.Wrapf(err, "invalid user %s", name)
	}

	// set process attr
	// 获取用户 id
	uid, err := strconv.ParseUint(user.Uid, 10, 32)
	if err != nil {
		return err
	}
	// 获取用户组 id
	gid, err := strconv.ParseUint(user.Gid, 10, 32)
	if err != nil {
		return err
	}
	attr := cmd.SysProcAttr
	//设置进程执行用户
	attr.Credential = &syscall.Credential{
		Uid:         uint32(uid),
		Gid:         uint32(gid),
		NoSetGroups: true,
	}

	cmd.SysProcAttr = attr
	return nil
}
```

1.首先检测 user name 是否合法
2.更新进程的启动用户属性