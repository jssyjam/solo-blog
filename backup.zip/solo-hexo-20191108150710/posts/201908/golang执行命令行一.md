title: golang 执行命令行(一)
date: '2019-08-02 15:47:29'
updated: '2019-11-05 19:53:29'
tags: [golang, 杂货铺]
permalink: /articles/2019/08/02/1564732049754.html
---
```golang```中会经常遇到要 fork 子进程的需求。go 标准库为我们封装了 ```os/exec```标准包,当我们要运行外部命令时应该优先使用这个库。

# 执行 command

这里我简单结合```context``` 和 ```Cmd``` 模块写一个通用的执行 command 方法。代码如下:

```go
func RunCmd(ctx context.Context, cmd *exec.Cmd) error {
	if err := withGroupAttr(cmd); err != nil {
		return err
	}

	if err := cmd.Start(); err != nil {
		return err
	}

	errCh := make(chan error, 1)
	go func() {
		errCh <- cmd.Wait()
	}()

	done := ctx.Done()
	for {
		select {
		case <-done:
			done = nil
			pid := cmd.Process.Pid
			if err := syscall.Kill(-1*pid, syscall.SIGKILL); err != nil {
				return err
			}
		case err := <-errCh:
			if done == nil {
				return ctx.Err()
			}
			return err
		}
	}
}


```
# 进程组重置
当 command 执行的命令有子进程时,如果不设置子进程的进程组,那么会默认新创建一个进程组,此时进程组的 gid 是子进程的进程号.当 kill 掉父进程后,子进程会逃逸。因此我们需要重置子进程的进程组号。

golang 中重新设置进程组 id 的代码如下:

```go
// 修改进程的进程组
func withGroupAttr(cmd *exec.Cmd) error {
	attr := cmd.SysProcAttr
  //获取父进程的进程组 id
	gid, err := syscall.Getpgid(syscall.Getpid())
	if err != nil {
		return err
	}
  // 修改进程组 id
	attr.Setpgid = true
	attr.Pgid = gid
	cmd.SysProcAttr = attr
	return nil
}
```

注: 在 command start 前设置进程的属性

