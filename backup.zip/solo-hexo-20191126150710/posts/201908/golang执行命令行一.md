title: golang 执行命令行(一)
date: '2019-08-02 15:47:29'
updated: '2019-11-25 11:38:28'
tags: [golang, 杂货铺]
permalink: /articles/2019/08/02/1564732049754.html
---
```golang```中会经常遇到要 fork 子进程的需求。go 标准库为我们封装了 ```os/exec```标准包,当我们要运行外部命令时应该优先使用这个库。

# 执行 command

这里我简单结合```context``` 和 ```Cmd``` 模块写一个通用的执行 command 方法。代码如下:

```go
// RunCmd ...
func RunCmd(ctx context.Context, cmd *exec.Cmd) error {
	if err := cmd.Start(); err != nil {
		return err
	}

	errCh := make(chan error, 1)
	go func() {
		errCh <- cmd.Wait()
	}()

	done := ctx.Done()
	for {
		select {
		case <-done:
			done = nil
			pid := cmd.Process.Pid
			if err := syscall.Kill(-1*pid, syscall.SIGKILL); err != nil {
				return err
			}
		case err := <-errCh:
			if done == nil {
				return ctx.Err()
			}
			return err
		}
	}
}


```