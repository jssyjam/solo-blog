title: 错题集(一) - gorm 批量插入数据
date: '2019-10-31 20:12:25'
updated: '2019-10-31 20:12:25'
tags: [错题集]
permalink: /articles/2019/10/31/1572523945633.html
---
使用[gorm](https://github.com/jinzhu/gorm) 插入数据的时候,根据官方文档可以使用```Create```或者```FirstOrCreate()```. 但是官方没有提供批量插入数据的方法.

根据```github```的 [issue](https://github.com/jinzhu/gorm/issues/255)得知,我们可以通过自己拼接```sql```语句进行批量数据插入(或许这是官方提供方法之前最好的解决方案了)具体实现如下:

假设有如下数据库表结构:

```sql
CREATE TABLE `employees` (
    `id` int(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
    `name` varchar(64) NOT NULL COMMENT '雇员姓名',
    `age` TINYINT(5) NOT NULL COMMENT '雇员年龄',
    `addr` varchar(64) NOT NULL COMMENT '雇员家庭地址',
     PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='雇员信息表';
```

批量操作如下:

```go
// Employee ...
type Employee struct {
	Name string `gorm:"column:name"`
	Age  int    `gorm:"column:age"`
	Addr string `gorm:"column:addr"`
}

// BatchSave 批量插入数据
func BatchSave(db *gorm.DB, emps []*Employee) error {
	var buffer bytes.Buffer
	sql := "insert into `employees` (`name`,`age`,`addr`) values"
	if _, err := buffer.WriteString(sql); err != nil {
		return err
	}
	for i, e := range emps {
		if i == len(emps)-1 {
			buffer.WriteString(fmt.Sprintf("('%s','%d',%s);", e.Name, e.Age, e.Addr))
		} else {
			buffer.WriteString(fmt.Sprintf("('%s','%d',%s),", e.Name, e.Age, e.Addr))
		}
	}
	return db.Exec(buffer.String()).Error
}
```

后续考虑分装一下```BatchCreate```方法