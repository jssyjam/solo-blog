title: docker 部署 nsq
date: '2019-09-17 11:39:32'
updated: '2019-09-17 20:21:32'
tags: [nsq]
permalink: /articles/2019/09/17/1568691572607.html
---
![](https://img.hacpai.com/bing/20180511.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

这篇文章主要介绍如何使用```docker```部署 nsq 组件
# 环境准备
本文基于一台 ubuntu 虚拟机试验
## docker 安装
[docker 安装方式](https://docs.docker.com/install/linux/docker-ce/ubuntu/)
使用```docker version``` 命令检查 docker 是否安装成功
## docker-compose 安装
```apt-get install docker-compose```
# nsq docker 部署
nsq 主要有三个组件: nsqlookupd, nsqd, nsqadmin。这三个组件都包含在 nsqio/nsq 镜像中, 每一个组件都可以通过指定组件名的方式去启动,启动命令的形式如下:
```docker run nsqio/nsq /command``
首先拉取基础镜像
```docker pull nsqio/nsq```
## docker部署
### nsqlookupd
```docker run --name lookupd -p 4160:4160 -p 4161:4161 -d nsqio/nsq /nsqlookupd```
说明:
* -p 是映射端口
* -d 是后台运行容器
* /nsqlookupd 就是启动命令
### nsqd 
首先通过```ifconfig```获取虚拟机的 ip, 以本机 ip 172.16.49.92为例, nsq 的启动命令如下:
``` docker run --name nsqd -p 4150:4150 -p 4151:4151  -d   nsqio/nsq /nsqd  --broadcast-address=172.16.49.92  --lookupd-tcp-address=172.16.49.92:4160```
持久化保存 nsqd 数据 使用/data 参数:
```--data-path=/data```
### nsqadmin
```docker run -d --name nsqadmin -p 4171:4171 nsqio/nsq /nsqadmin --lookupd-http-address=172.16.49.92:4161```
访问  http://172.16.49.92:4161 就可以查看 nsq系统详情了
### 测试验证
1.``` curl 172.16.49.92:4161/nodes```调用 lookupd 接口查看节点信息
```json {"producers":[{"remote_address":"172.17.0.1:46290","hostname":"6c684bee454b","broadcast_address":"172.16.49.92","tcp_port":4150,"http_port":4151,"version":"1.2.0","tombstones":[],"topics":[]}]}```
2.```curl -d 'hello world ' 'http://127.0.0.1:4151/pub?topic=test'```生产一个消息,同时也创建了一个topic。
调用 lookupd 的 /topics 接口返回 ```json {"topics":["test"]}```
3.通过```docker logs containerID```查看各个组件的日志详情
4.直接访问 http://172.16.49.92:4171 就可以访问 nsqadmin 的首页
![image-20190917111708533](http://139.155.1.103:9000/nsq/image-20190917111708533.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=QO3UL8XGJN79FRNPIC6S%2F20190917%2F%2Fs3%2Faws4_request&X-Amz-Date=20190917T122122Z&X-Amz-Expires=432000&X-Amz-SignedHeaders=host&X-Amz-Signature=b1ca314ec63a9a5c51a6ff5bc5461e236b8b78e36c2d5fa2d2cb276e3c1cc04d)
nodes 详情页:
![image-20190917111738345](http://139.155.1.103:9000/nsq/image-20190917111738345.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=QO3UL8XGJN79FRNPIC6S%2F20190917%2F%2Fs3%2Faws4_request&X-Amz-Date=20190917T122055Z&X-Amz-Expires=604800&X-Amz-SignedHeaders=host&X-Amz-Signature=8af7f639fb1f41289191e8b7fc8d046f1c7301285374b17596ae697253892cd8)
## docker-compose 部署
docker-compose 可以轻松、高效的管理容器，它是一个用于定义和运行多容器 Docker 的应用程序工具.
要使用 dokcer-compose 部署,我们首先需要编写 yaml 文件, docker-compose.yml 文件如下:

```yaml
version: '3'
services:
  nsqlookupd:
    image: nsqio/nsq
    command: /nsqlookupd
    ports:
      - "4160"
      - "4161"
  nsqd:
    image: nsqio/nsq
    command: /nsqd --lookupd-tcp-address=nsqlookupd:4160
    depends_on:
      - nsqlookupd
    ports:
      - "4150"
      - "4151"
  nsqadmin:
    image: nsqio/nsq
    command: /nsqadmin --lookupd-http-address=nsqlookupd:4161
    depends_on:
      - nsqlookupd  
    ports:
      - "4171"
```
定义了三个服务模块: nsqlookupd, nsqd, nsqadmin. 具体的 docker-compose 使用可以参考: [docker-compose 使用](https://docs.docker.com/compose/)
docker-compose up -d 启动nsq 所有组件
docker-compose ps 查看各个组件的运行详情
docker-compose logs 查看组件日志
其他常用命令可以通过 ```docker-compose --help```查看